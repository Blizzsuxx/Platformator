#pragma once

#include "buildconfig.h"

#include <Eigen/Dense>

inline const Eigen::Vector2f X_AXIS(1.0f, 0.0f);
inline const Eigen::Vector2f Y_AXIS(0.0f, 1.0f);

constexpr float SCREEN_WIDTH = 1920.0f;
constexpr float SCREEN_HEIGHT = 1080.0f;
constexpr int TARGET_FPS = 120;
constexpr const double FRAME_TIME = 1.0 / static_cast<double>(TARGET_FPS);
constexpr double FIXED_TIME_STEP = 1.0 / 120.0;
constexpr unsigned MAXIMUM_CATCH_UP_STEPS = 8;

constexpr float SUPPORT_NORMAL_THRESHOLD = 0.85f;
constexpr float LINEAR_SLEEP_THRESHOLD = 5.0f;
constexpr float ANGULAR_SLEEP_THRESHOLD = 0.05f;
constexpr double SLEEP_DELAY = 0.25;

constexpr float WAKE_LINEAR_EPSILON = 1e-3f;
constexpr float WAKE_LINEAR_EPSILON_SQUARED = WAKE_LINEAR_EPSILON * WAKE_LINEAR_EPSILON;
constexpr float WAKE_ANGULAR_EPSILON = 1e-4f;

constexpr float GRID_CELL_SIZE = 200.0f;
constexpr float GRAVITY_VECTOR_X = 0.0f;
constexpr float GRAVITY_VECTOR_Y = 98.10f;

constexpr size_t COLLISION_SOLVER_ITERATIONS = 10;
constexpr float COLLISION_ALLOWED_PENETRATION = 0.01f;
constexpr float COLLISION_BIAS_FACTOR = 0.2f;
constexpr float RESTITUTION_VELOCITY_THRESHOLD = 1.0f;
constexpr size_t MAX_CHUNK_SIZE = 32;
constexpr size_t NARROW_PHASE_PARALLEL_THRESHOLD = 64;
